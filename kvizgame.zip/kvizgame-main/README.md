# kvizgame
Kviz Játék tantárgyakbol c# win formosban
!!!FIGYELEM!!!
A beolvasott txt a következő képpen nézzen ki.
Txt felépités
tantárgyneve //Új sorban
kerdés;jóválasz,elsőrosszválasz,másodikrosszválasz;pontszám
!!!!!az elemeket ; jelell válaszd el!!!!!!
